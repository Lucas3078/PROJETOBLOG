<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Clientes</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 20px;
            background-color: #f0f0f0;
        }
        form {
            max-width: 400px;
            margin: auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        fieldset {
            border: 1px solid #ccc;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 5px;
        }
        legend {
            font-size: 1.2em;
            margin-bottom: 10px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }
        input[type="text"], input[type="email"], input[type="tel"] {
            width: calc(100% - 18px); 
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
            box-sizing: border-box;
            font-size: 1em;
            margin-bottom: 10px;
        }
        button[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            font-size: 1em;
            transition: background-color 0.3s;
        }
        button[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <form action="CadastroClienteExe.php" method="post">
        <fieldset>
            <legend>Cadastro de Cliente</legend>
            <div>
                <label for="nome">Nome:</label>
                <input type="text" name="nome" id="nome" required>
            </div>
            <div>
                <label for="email">Email:</label>
                <input type="email" name="email" id="email" required>
            </div>
            <div>
                <label for="telefone">Senha:</label>
                <input type="password" name="senha" id="senha" required>
            </div>

            <h3>Situação</h3>
            <div id="ativo">
                <label for="operacao">Ativo</label>
                <input type="checkbox" name="ativo" id="ativo" value="1">
            </div> <p></p>

            <div>
                <label for="cidade">Cidade</label>
                <select name="cidade" id="cidade">
                    <?php
                    include('includes/conexão.php');
                    
                    $sql = "SELECT * FROM cidade";
                    $result = mysqli_query($con,$sql);

                    while($row = mysqli_fetch_array($result)){
                        echo "<option value='".$row['id']."'>" .$row['nome'] ."/" .$row['estado'] ."</option>";
                    }
                    ?>
                </select>
            </div>

            <div style="text-align: center;">
                <button type="submit">Cadastrar</button>
            </div>
        </fieldset>    
    </form>
    <a href="index.html">Voltar para a Tela Inicial</a>
</body>
</html>
