<?php
include('includes/conexão.php');

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $sql = "DELETE FROM cliente WHERE id = ?";

    $stmt = mysqli_prepare($con, $sql);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "i", $id);

        $result = mysqli_stmt_execute($stmt);

        if ($result) {
            header("Location: ListarCliente.php");
            exit;
        } else {
            echo "Erro ao executar a exclusão: " . mysqli_error($con);
        }

        mysqli_stmt_close($stmt);
    } else {
        echo "Erro ao preparar a declaração: " . mysqli_error($con);
    }

    mysqli_close($con);
} else {
    header("Location: ListarCliente.php");
    exit;
}
?>
