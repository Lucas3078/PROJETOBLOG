<?php
include('includes/conexão.php');

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $sql = "SELECT * FROM cliente WHERE id = $id";
    $result = mysqli_query($con, $sql);

    if ($result) {
        
        if (mysqli_num_rows($result) == 1) {
            
            $row = mysqli_fetch_assoc($result);
        } else {
            echo "Cliente não encontrado.";
            exit; 
        }
    } else {
        echo "Erro ao consultar cliente: " . mysqli_error($con);
        exit; 
    }
} else {
    echo "ID do cliente não especificado.";
    exit; 
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alteração de Cliente</title>
    
</head>
<body>
    <form action="AlteraClienteExe.php" method="post">
        <fieldset>
            <legend>Alteração de Cliente</legend>
            <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
            <div>
                <label for="nome">Nome:</label>
                <input type="text" name="nome" id="nome" value="<?php echo $row['nome']; ?>" required>
            </div>
            <div>
                <label for="email">E-mail:</label>
                <input type="email" name="email" id="email" value="<?php echo $row['email']; ?>" required>
            </div>
            <div>
                <label for="senha">Senha:</label>
                <input type="password" name="senha" id="senha" value="<?php echo $row['senha']; ?>" required>
            </div>
            <div style="text-align: center;">
                <button type="submit">Salvar Alterações</button>
            </div>
        </fieldset>    
    </form>
</body>
</html>

